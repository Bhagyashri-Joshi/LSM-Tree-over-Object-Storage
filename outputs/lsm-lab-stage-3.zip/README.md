# LSM Lab

LSM Lab is an educational, browser-based simulator for exploring an LSM-tree storage engine over **simulated** object storage. Stage 2 adds a deterministic, in-memory storage lifecycle behind the existing SVG architecture shell. It has no cloud provider, backend, credentials, or external persistence.

## Requirements

- Node.js 20 or newer
- npm 10 or newer

## Run locally

```bash
npm install
npm run dev
```

Open the local address Vite prints in the terminal.

## Commands

```bash
npm run dev       # development server
npm run build     # TypeScript check and production build
npm run preview   # preview a production build
npm test          # run the Vitest suite once
```

## Current capabilities

- Responsive dark application shell with component palette and metrics toolbar
- SVG topology canvas with connected Client, LSM Engine, MemTable, and Object Storage nodes
- Working canvas pan, zoom, and reset-view controls
- Editable offered-load input, retained as configuration only until a workload runner is implemented
- Disabled workload controls; the workload scheduler and live UI metrics arrive in Stage 3
- Initial domain types for topology, status, connections, and metric snapshots
- Simulated in-memory object storage with prefix listing, bytes/operation accounting, fixed latency, and deterministic failure injection
- WAL-backed `PUT`, `UPDATE`, `DELETE` (tombstone), `GET`, memtable flushing, SSTable serialization, and explicit compaction
- Deterministic, repeatable workloads: Write-heavy, Read-heavy, Burst writes, and Compaction pressure
- Functional Start, Pause, Step, and Reset controls with a simulated clock, live event log, topology highlights, and actual engine/storage metrics

## Running a simulation

Start the development server with `npm run dev`. Choose a workload in the toolbar, then use:

- **Start** to execute operations at the selected offered-load cadence.
- **Pause** to stop automatic execution without clearing state.
- **Step** to run exactly one deterministic operation.
- **Reset** to recreate the engine, simulated object store, clock, and workload from the same seed.

The event log records chronological simulated timestamps, operation details, flush/compaction events, and storage failures. The canvas highlights active topology paths based on the actual operation just completed.

## Live metric formulas

- **Completed / successful / failed operations:** counted from actual controller results.
- **Throughput:** `successful operations ÷ simulated elapsed seconds`.
- **Latency:** deterministic logical operation time: `1 ms + object-store operations caused by that request`; p99 is the 99th percentile of these samples.
- **Flushes / compactions:** lifecycle events emitted by the LSM engine.
- **Object operations and bytes:** counters from the simulated object store, including upload, read, list, delete, stored, and uploaded bytes.
- **Write amplification:** `SSTable bytes uploaded to simulated object storage ÷ logical bytes in successful client write requests`. It includes compaction rewrites and remains `0` before the first successful logical write.

## Storage lifecycle

Each write is single-threaded and deterministic:

1. The engine assigns a strictly increasing sequence number.
2. It appends the mutation to the supplied Write-Ahead Log (WAL).
3. It applies the mutation to the MemTable.
4. When the configured unique-key threshold is reached, the engine serializes a stable, key-sorted SSTable and uploads it to the simulated object store.
5. Only after upload success does it publish SSTable metadata and clear the MemTable entries.

Reads first consider the MemTable, then every active SSTable, choosing the highest sequence number. Tombstones therefore remain authoritative across flushes. Compaction reads the complete active catalogue, writes the replacement table before publishing it, and only then deletes obsolete objects. Because every active table participates, tombstones may be removed safely when no live values remain.

## Durability assumptions and limitations

- The `WriteAheadLog` is an in-memory, replayable model. Restart recovery is demonstrated only when the same WAL instance is supplied to a new engine instance.
- The object store is explicitly simulated and in-memory. It does not claim S3/MinIO compatibility, network durability, or real crash safety.
- SSTable catalogue metadata is held in the engine process. WAL replay restores the latest mutations into a fresh MemTable, but catalogue persistence is not yet modeled.
- Operations are deliberately synchronous from the engine's point of view; no background flushing, concurrent writes, range scans, Bloom filters, or production compaction policy are included.
- The simulated clock and latency are educational models, not wall-clock benchmarks. The Stage 3 runner has no request queue, backpressure model, or persistent scenario storage.

## Tests

The Vitest suite covers app rendering plus object-store prefix filtering, missing-object errors, injected failures, PUT/GET, updates, tombstones, flush thresholds, version selection across SSTables, serialization, compaction, failed uploads, and WAL replay.

## Planned boundaries

The future workload scheduler and live metric collector remain independent from the LSM engine and storage adapter. No cloud provider, database, backend service, credentials, or real object storage is included.
