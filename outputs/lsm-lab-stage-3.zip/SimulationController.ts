import { LSMEngine, type LSMEngineEvent } from '../domain/lsm'
import { SimulatedObjectStore, type FailureRule, type SimulatedObjectStoreOptions } from '../domain/object-storage'
import { SimulationClock } from './SimulationClock'
import { createWorkload, type WorkloadKind, type WorkloadOperation } from './workloads'

export type SimulationRunStatus = 'ready' | 'running' | 'paused' | 'complete'

export interface SimulationMetrics {
  completedOperations: number
  successfulOperations: number
  failedOperations: number
  throughputOpsPerSecond: number
  averageLatencyMs: number
  p99LatencyMs: number
  flushes: number
  compactions: number
  objectOperations: number
  objectBytesWritten: number
  objectBytesRead: number
  physicalBytes: number
  logicalWriteBytes: number
  /** SSTable bytes uploaded / logical client write bytes. Zero until a write is accepted. */
  writeAmplification: number
}

export interface SimulationEvent {
  id: number
  timestampMs: number
  operation: WorkloadOperation
  outcome: 'success' | 'failure'
  detail: string
  latencyMs: number
  storageOperations: number
  lifecycleEvents: LSMEngineEvent[]
}

export interface SimulationSnapshot {
  status: SimulationRunStatus
  workload: WorkloadKind
  offeredLoadOpsPerSecond: number
  operationIndex: number
  operationCount: number
  clockMs: number
  metrics: SimulationMetrics
  events: SimulationEvent[]
  activeConnectionIds: string[]
}

export interface SimulationControllerOptions {
  workload?: WorkloadKind
  seed?: number
  operationCount?: number
  offeredLoadOpsPerSecond?: number
  storeOptions?: SimulatedObjectStoreOptions
  failureRules?: FailureRule[]
}

const emptyMetrics = (): SimulationMetrics => ({
  completedOperations: 0, successfulOperations: 0, failedOperations: 0,
  throughputOpsPerSecond: 0, averageLatencyMs: 0, p99LatencyMs: 0,
  flushes: 0, compactions: 0, objectOperations: 0, objectBytesWritten: 0,
  objectBytesRead: 0, physicalBytes: 0, logicalWriteBytes: 0, writeAmplification: 0,
})

/** Coordinates one deterministic workload with the real Stage 2 engine and simulated store. */
export class SimulationController {
  private readonly clock = new SimulationClock()
  private readonly seed: number
  private readonly operationCount: number
  private readonly storeOptions: SimulatedObjectStoreOptions
  private operations: WorkloadOperation[] = []
  private status: SimulationRunStatus = 'ready'
  private cursor = 0
  private sequence = 0
  private offeredLoad: number
  private selectedWorkload: WorkloadKind
  private store!: SimulatedObjectStore
  private engine!: LSMEngine
  private metrics = emptyMetrics()
  private events: SimulationEvent[] = []
  private latencies: number[] = []
  private activeConnectionIds: string[] = []

  constructor(options: SimulationControllerOptions = {}) {
    this.seed = options.seed ?? 17
    this.operationCount = options.operationCount ?? 36
    this.selectedWorkload = options.workload ?? 'write-heavy'
    this.offeredLoad = options.offeredLoadOpsPerSecond ?? 10
    this.storeOptions = { ...options.storeOptions, failures: [...(options.storeOptions?.failures ?? []), ...(options.failureRules ?? [])] }
    this.rebuild()
  }

  start(): void { if (this.status !== 'complete') this.status = 'running' }
  pause(): void { if (this.status === 'running') this.status = 'paused' }
  setOfferedLoad(value: number): void { this.offeredLoad = Math.max(1, Math.min(100000, Math.floor(value) || 1)) }
  setWorkload(workload: WorkloadKind): void { if (this.status !== 'running') { this.selectedWorkload = workload; this.reset() } }
  reset(): void { this.rebuild() }

  async step(): Promise<SimulationEvent | undefined> {
    if (this.status === 'complete') return undefined
    const operation = this.operations[this.cursor]
    if (!operation) { this.status = 'complete'; return undefined }
    const before = this.store.getStats()
    let outcome: SimulationEvent['outcome'] = 'success'
    let detail = ''
    try {
      if (operation.kind === 'get') {
        const result = await this.engine.get(operation.key)
        detail = result.found ? `GET ${operation.key} → ${result.value}` : `GET ${operation.key} → miss`
      } else if (operation.kind === 'delete') {
        await this.engine.delete(operation.key)
        this.metrics.logicalWriteBytes += byteLength(operation.key)
        detail = `DELETE ${operation.key}`
      } else if (operation.kind === 'update') {
        await this.engine.update(operation.key, operation.value!)
        this.metrics.logicalWriteBytes += byteLength(operation.key) + byteLength(operation.value!)
        detail = `UPDATE ${operation.key}`
      } else {
        await this.engine.put(operation.key, operation.value!)
        this.metrics.logicalWriteBytes += byteLength(operation.key) + byteLength(operation.value!)
        detail = `PUT ${operation.key}`
      }
      this.metrics.successfulOperations += 1
    } catch (error) {
      outcome = 'failure'
      this.metrics.failedOperations += 1
      detail = error instanceof Error ? error.message : String(error)
    }
    const after = this.store.getStats()
    const storageOperations = (after.putCount - before.putCount) + (after.getCount - before.getCount) + (after.listCount - before.listCount) + (after.deleteCount - before.deleteCount)
    const latencyMs = 1 + storageOperations
    this.clock.advance(latencyMs)
    this.latencies.push(latencyMs)
    const lifecycleEvents = this.engine.drainEvents()
    this.metrics.completedOperations += 1
    this.metrics.flushes += lifecycleEvents.filter((event) => event.type === 'flush').length
    this.metrics.compactions += lifecycleEvents.filter((event) => event.type === 'compaction').length
    this.cursor += 1
    if (this.cursor >= this.operations.length) this.status = 'complete'
    else if (this.status !== 'running') this.status = 'paused'
    this.refreshMetrics()
    this.activeConnectionIds = activeConnections(operation, lifecycleEvents, outcome)
    const event: SimulationEvent = { id: ++this.sequence, timestampMs: this.clock.now, operation: { ...operation }, outcome, detail, latencyMs, storageOperations, lifecycleEvents }
    this.events = [event, ...this.events].slice(0, 80)
    return event
  }

  snapshot(): SimulationSnapshot {
    return {
      status: this.status, workload: this.selectedWorkload, offeredLoadOpsPerSecond: this.offeredLoad,
      operationIndex: this.cursor, operationCount: this.operations.length, clockMs: this.clock.now,
      metrics: { ...this.metrics }, events: this.events.map((event) => ({ ...event, operation: { ...event.operation }, lifecycleEvents: [...event.lifecycleEvents] })),
      activeConnectionIds: [...this.activeConnectionIds],
    }
  }

  private rebuild(): void {
    this.clock.reset()
    this.store = new SimulatedObjectStore(this.storeOptions)
    this.engine = new LSMEngine({ objectStorage: this.store, memtableMaxEntries: 4, level0CompactionTrigger: 3 })
    this.operations = createWorkload(this.selectedWorkload, this.seed, this.operationCount)
    this.status = 'ready'; this.cursor = 0; this.sequence = 0; this.metrics = emptyMetrics(); this.events = []; this.latencies = []; this.activeConnectionIds = []
  }

  private refreshMetrics(): void {
    const stats = this.store.getStats()
    this.metrics.objectOperations = stats.putCount + stats.getCount + stats.listCount + stats.deleteCount
    this.metrics.objectBytesWritten = stats.putBytes
    this.metrics.objectBytesRead = stats.getBytes
    this.metrics.physicalBytes = stats.storedBytes
    this.metrics.writeAmplification = this.metrics.logicalWriteBytes === 0 ? 0 : stats.putBytes / this.metrics.logicalWriteBytes
    this.metrics.averageLatencyMs = this.latencies.reduce((sum, value) => sum + value, 0) / this.latencies.length
    const sorted = [...this.latencies].sort((a, b) => a - b)
    this.metrics.p99LatencyMs = sorted.length === 0 ? 0 : sorted[Math.min(sorted.length - 1, Math.ceil(sorted.length * 0.99) - 1)]
    this.metrics.throughputOpsPerSecond = this.clock.now === 0 ? 0 : this.metrics.successfulOperations / (this.clock.now / 1000)
  }
}

function byteLength(value: string): number { return new TextEncoder().encode(value).byteLength }
function activeConnections(operation: WorkloadOperation, lifecycleEvents: LSMEngineEvent[], outcome: SimulationEvent['outcome']): string[] {
  if (outcome === 'failure') return ['client-engine']
  if (lifecycleEvents.length > 0) return ['engine-memtable', 'engine-storage']
  return operation.kind === 'get' ? ['client-engine'] : ['client-engine', 'engine-memtable']
}
