import { ArchitectureCanvas } from '../canvas/ArchitectureCanvas'
import { useSimulation } from '../state/useSimulation'
import { ComponentPalette } from '../ui/ComponentPalette'
import { EventLog } from '../ui/EventLog'
import { TopToolbar } from '../ui/TopToolbar'

export function App() {
  const simulation = useSimulation()
  return (
    <main className="min-h-screen bg-ink text-slate-100">
      <TopToolbar {...simulation} />
      <section className="flex h-[calc(100vh-72px)] min-h-[560px] overflow-hidden">
        <ComponentPalette />
        <ArchitectureCanvas snapshot={simulation.snapshot} />
        <EventLog events={simulation.snapshot.events} />
      </section>
    </main>
  )
}
