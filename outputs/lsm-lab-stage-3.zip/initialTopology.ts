import type { SimulationTopology } from './simulation'

export const initialTopology: SimulationTopology = {
  components: [
    { id: 'client', kind: 'client', label: 'Client', category: 'traffic', position: { x: 80, y: 220 }, description: 'Generates reads and writes.' },
    { id: 'lsm-engine', kind: 'lsm-engine', label: 'LSM Engine', category: 'compute', position: { x: 350, y: 220 }, description: 'Future home of the write and read paths.' },
    { id: 'memtable', kind: 'memtable', label: 'MemTable', category: 'data', position: { x: 625, y: 120 }, description: 'An in-memory write buffer.' },
    { id: 'object-storage', kind: 'object-storage', label: 'Object Storage', category: 'data', position: { x: 625, y: 350 }, description: 'Simulated durable SSTable storage.' },
  ],
  connections: [
    { id: 'client-engine', sourceId: 'client', targetId: 'lsm-engine', label: 'requests', status: 'idle' },
    { id: 'engine-memtable', sourceId: 'lsm-engine', targetId: 'memtable', label: 'buffer', status: 'idle' },
    { id: 'engine-storage', sourceId: 'lsm-engine', targetId: 'object-storage', label: 'SSTables', status: 'idle' },
  ],
}
